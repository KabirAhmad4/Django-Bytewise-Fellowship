# imports here
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.proxy import Proxy, ProxyType
from webdriver_manager.chrome import ChromeDriverManager
import time
import random
import pandas as pd
import requests
from .extension import proxies
# import pickle
# import os.path

# global variables
proxy = {}
my_email = ""
my_password = ""
cached_driver = None

# def login_facebook(my_email, my_password):
#     print("In login_facebook function")
#     global cached_driver
#     cookieFilePath = my_email + '.pkl'

#     print("Cached driver: ", cached_driver)
#     # Check if the driver is window is closed
#     if cached_driver is not None:
#         try:
#             cached_driver.current_url
#             print("Using cached login session.")
#             return cached_driver
#         except Exception as e:
#             print("Error occurred while checking the driver:", str(e))
#             cached_driver.quit()
#             cached_driver = None

#     # Set up proxy options for Chrome
#     chrome_options = webdriver.ChromeOptions()

#     # Add the proxy extension to the browser
#     proxies_extension = proxies(
#         proxy["username"], proxy["password"], proxy["endpoint"], proxy["port"]
#     )
#     # chrome_options.add_extension(proxies_extension)

#     # Add other options as needed
#     prefs = {"profile.default_content_setting_values.notifications": 2}
#     chrome_options.add_experimental_option("prefs", prefs)

#     # Check if the cookies file exists
#     if os.path.exists(cookieFilePath):
#         print("Loading cookies...")
#         # Load cookies from file
#         with open(cookieFilePath, 'rb') as f:
#             cookies = pickle.load(f)
        
#         # Initialize Chrome browser with ChromeDriver managed by the service and additional options
#         driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()), options=chrome_options)

#         # Set up Chrome options with loaded cookies
#         for cookie in cookies:
#             cookie['domain'] = ".facebook.com"
#             try:
#                 driver.add_cookie(cookie)
#             except Exception as e:
#                 print("An error occurred while adding cookie:", str(e))
        
#         # Cache the driver after successful login
#         cached_driver = driver

#         # Return the driver with loaded cookies
#         return driver
    
#     else:
#         try: 
#             # Initialize Chrome browser with ChromeDriver managed by the service and additional options
#             driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()), options=chrome_options)
    
#             # open the webpage
#             driver.get("https://www.facebook.com/")
    
#             # target username
#             username = WebDriverWait(driver, 10).until(
#                 EC.element_to_be_clickable((By.CSS_SELECTOR, "input[name='email']"))
#             )
#             password = WebDriverWait(driver, 10).until(
#                 EC.element_to_be_clickable((By.CSS_SELECTOR, "input[name='pass']"))
#             )
    
#             # enter username or password
#             username.clear()
#             username.send_keys(my_email)
#             password.clear()
#             password.send_keys(my_password)
    
#             # target the login button and click it
#             button = (
#                 WebDriverWait(driver, 2)
#                 .until(
#                     EC.element_to_be_clickable((By.CSS_SELECTOR, "button[type='submit']"))
#                 )
#                 .click()
#             )
    
#             time.sleep(random.randint(6, 10))  # wait for 5 seconds to load the page
    
#             #  Wait for the welcome page to load
#             print(driver.current_url)
#             while driver.current_url not in ["https://www.facebook.com/?sk=welcome", "https://www.facebook.com/", "https://web.facebook.com/", "https://web.facebook.com/?sk=welcome"]:
#                 print("Logging in")
#                 time.sleep(5)
    
#             print("New Logged in") # you should be logged in by now
    
#             # Cache the driver after successful login
#             cached_driver = driver
    
#             # Get and store cookies
#             cookies = driver.get_cookies()
#             with open(cookieFilePath, 'wb') as f:
#                 pickle.dump(cookies, f)
    
#             return driver
    
#         except Exception as e:
#             print("An error occurred while logging into Facebook:", str(e))
#             return None

def login_facebook(my_email, my_password):
    # Login Facebook
    print("In login_facebook function")

    global cached_driver

    print("Cached driver: ", cached_driver)
    # Check if the driver is window is closed
    if cached_driver is not None:
        try:
            cached_driver.current_url
            print("Using cached login session.")
            return cached_driver
        except Exception as e:
            print("Error occurred while checking the driver:", str(e))
            cached_driver.quit()
            cached_driver = None    

    try:
        # Set up proxy options for Chrome
        chrome_options = webdriver.ChromeOptions()

        # Add the proxy extension to the browser
        proxies_extension = proxies(
            proxy["username"], proxy["password"], proxy["endpoint"], proxy["port"]
        )
        chrome_options.add_extension(proxies_extension)

        # Add other options as needed
        prefs = {"profile.default_content_setting_values.notifications": 2}
        chrome_options.add_experimental_option("prefs", prefs)

        # Initialize Chrome browser with ChromeDriver managed by the service and additional options
        driver = webdriver.Chrome(
            service=ChromeService(ChromeDriverManager().install()),
            options=chrome_options,
        )

        # open the webpage
        driver.get("https://wwww.facebook.com/")

        # target username
        username = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "input[name='email']"))
        )
        password = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "input[name='pass']"))
        )

        # enter username or password
        username.clear()
        username.send_keys(my_email)
        password.clear()
        password.send_keys(my_password)

        # target the login button and click it
        button = (
            WebDriverWait(driver, 2)
            .until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "button[type='submit']"))
            )
            .click()
        )

        time.sleep(random.randint(6, 10))  # wait for 5 seconds to load the page

        #  Wait for the welcome page to load
        print(driver.current_url)
        while driver.current_url not in ["https://www.facebook.com/?sk=welcome", "https://www.facebook.com/", "https://web.facebook.com/", "https://web.facebook.com/?sk=welcome"]:
            print("Logging in")
            time.sleep(5)

        print("New Logged in") # you should be logged in by now

        # Cache the driver after successful login
        cached_driver = driver
        return driver

    except Exception as e:
        print("An error occurred while logging into Facebook:", str(e))
        return None


def get_chats(username, password, proxy_credentials):
    # Login Facebook
    global my_email
    global my_password
    global proxy
    global cached_driver

    print("my_email " + my_email)
    print("usernaem" + username)
    if my_email != username:
        print("Setting cached driver to None")
        try:
            cached_driver.quit()
        except Exception as e:
            print("Error occurred while quiting the driver:", str(e))
        cached_driver = None

    my_email = username
    my_password = password
    proxy = proxy_credentials

    driver = login_facebook(my_email, my_password)
    print("In get_chats function")
    try:

        # Move to the Messages page
        driver.get("https://www.facebook.com/messages/t")

        time.sleep(random.randint(5, 10))  # wait for 5 seconds to load the page

        # click on the Marketplace for displaying all the messages
        div_element = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable(
                (
                    By.CSS_SELECTOR,
                    "div.x1i10hfl.x1qjc9v5.xjbqb8w.xjqpnuy.xa49m3k.xqeqjp1.x2hbi6w.x13fuv20.xu3j5b3.x1q0q8m5.x26u7qi.x972fbf.xcfux6l.x1qhh985.xm0m39n.x9f619.x1ypdohk.xdl72j9.x2lah0s.xe8uvvx.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.x2lwn1j.xeuugli.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1n2onr6.x16tdsg8.x1hl2dhg.xggy1nq.x1ja2u2z.x1t137rt.x1q0g3np.x87ps6o.x1lku1pv.x1a2a7pz.x1lq5wgf.xgqcy7u.x30kzoy.x9jhf4c.x1lliihq",
                )
            )
        )
        div_element.click()  # click on the Marketplace

        # scroll down to load all the messages
        time.sleep(random.randint(5, 10))

        # get the Marketplace scrollable element
        scroll_messages = driver.find_element(
            By.XPATH, '//div[@aria-label="Marketplace"]/div/div/div'
        )

        # SCrolling code
        # Get scroll height
        last_height = driver.execute_script(
            "return arguments[0].scrollHeight", scroll_messages
        )

        scroll = 4
        while scroll > 0:
            print("Scrolling")
            # Scroll down to bottom
            driver.execute_script(
                "arguments[0].scroll(0, arguments[0].scrollHeight);", scroll_messages
            )

            # Wait to load page
            time.sleep(random.randint(20, 30))

            # Calculate new scroll height and compare with last scroll height
            new_height = driver.execute_script(
                "return arguments[0].scrollHeight", scroll_messages
            )
            if new_height == last_height:
                break
            last_height = new_height
            scroll -= 1
        print("Scrolled to the bottom")

        # get the all inbox messages links
        links = scroll_messages.find_elements(By.TAG_NAME, "a")
        anchors = [a.get_attribute("href") for a in links]
        anchors_text = [a.text.split("\n")[0] for a in links]

        anchors = [
            a.split("https://www.facebook.com/messages/t/")[1].replace("/", "")
            for a in anchors
        ]

        # create a list of dictionary
        anchors = [
            {"name": anchors_text[i], "url": anchors[i]} for i in range(len(anchors))
        ]
        print(anchors)
        # driver.quit()
        print("Out of get_chats function")
        return anchors

    except Exception as e:
        print("An error occurred while getting chats:", str(e))
        return []


def get_messages(url, name):
    driver = login_facebook(my_email, my_password)

    # Open the message link page
    try:
        print("In get_messages function")
        print(driver.current_url)
        driver.get(url)
        print("URL: " + url)

        # wait for random seconds to load the page
        time.sleep(random.randint(5, 10))
        # scroll down to load all the messages
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

        # Find the whole message box
        messageBox = driver.find_element(By.XPATH, '//div[@aria-label="Messages in conversation titled ' + name + '"]')

        # Find all div messages divs
        messageBars = messageBox.find_elements(By.CLASS_NAME , '__fb-light-mode.x1n2onr6')
        if messageBars == []:
            messageBars = messageBox.find_elements(By.CLASS_NAME , '__fb-dark-mode.x1n2onr6')

        # get the total messages
        totalMsgs = len(messageBars)
        print(url)
        print("Before Filtering: " + str(totalMsgs))

        # filtering the messages removing unwanted texts
        # remove the only first message with following text
        text_to_remove = [
            "Buyer details",
            "Message sent\nEnter",
            "Beware of common scams using payment apps\nWatch out for fake emails or requests to upgrade your payment account.",
            "Learn more",
            "You created this group",
            "You're not connected to 1 member",
            "You changed the group photo.",
            "Send a quick response",
        ]
        for text in text_to_remove:
            messageBars = [x for x in messageBars if text not in x.text]
        print("After Filtering: " + str(len(messageBars)))

        # remove the last message with following text
        messages = []
        # for index, messageBar in enumerate(messageBars):
        for idx in range(0, len(messageBars), 2):
            # append the text first line as sender and second line as a message create a list of dictionary
            mTexts = messageBars[idx].text.split('\n')
            print(messageBars[idx].text)
            print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
            if idx + 1 >= len(messageBars):
                break
            print(messageBars[idx+1].text)
            print("******************************")
            messages.append({'sender': mTexts[0], 'message': messageBars[idx+1].text})
        # driver.quit()

        print(messages)
        print("Out of get_messages function")
        return messages

    except Exception as e:
        print("An error occurred while getting messages:", str(e))
        return []


def send_message(url, user_message):
    driver = login_facebook(my_email, my_password)
    print("In send_message function")

    try:
        driver.get(url)

        # wait for random seconds to load the page
        time.sleep(random.randint(5, 10))

        # Find the message input element
        message_input = driver.find_element(By.XPATH, '//div[@aria-label="Message"]/p')

        # Clear any existing text in the message input field
        message_input.clear()

        time.sleep(random.randint(5, 10))

        # Type the user's message into the input field
        message_input.send_keys(user_message)
        message_input.send_keys(Keys.RETURN)

        # wait
        time.sleep(random.randint(5, 10))

        print("Message sent")
        # driver.quit()
    
    except Exception as e:
        print("An error occurred while sending message:", str(e))
