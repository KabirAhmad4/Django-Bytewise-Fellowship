from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser
from django.views.decorators.csrf import csrf_exempt
from .scrapper import *
import csv
import json

messages = []

# Function to read accounts from CSV file
def read_accounts_from_csv(file_path):
    accounts = []
    with open(file_path, 'r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip header row if present
        for row in reader:
            if len(row) == 6:
                # Append the account details to the list
                print(row)
                accounts.append({'username': row[0], 'password': row[1],'proxy_username': row[2],'proxy_password': row[3],'proxy_endpoint': row[4],'proxy_port': row[5]})
    return accounts

# Django view to display account selection
def select_account(request):
    if request.method == 'GET':
        accounts = read_accounts_from_csv('accounts.csv')
        accounts = enumerate(accounts)
        
        return render(request, 'home/account_selection.html', {'accounts': accounts})
    elif request.method == 'POST':
        print("POST of select_account")
        selected_account_index = int(request.POST.get('selected_account'))
        selected_account = read_accounts_from_csv('accounts.csv')[selected_account_index]
        print(selected_account)
        # Pass the selected account details to other views or functions
        request.session['selected_account'] = selected_account
        return redirect('home')  # Redirect to home page or any other page
        
def home(request):
    if request.method == 'GET':
        print("In home function")
        selected_account = request.session.get('selected_account')
        print(selected_account)
        if selected_account:
            username = selected_account['username']
            password = selected_account['password']
            proxy_credentials = {
                'username': selected_account['proxy_username'],
                'password': selected_account['proxy_password'],
                'endpoint': selected_account['proxy_endpoint'],
                'port': selected_account['proxy_port']
            }

            print("brfore get_chats")
            chats = get_chats(username, password, proxy_credentials)
            print("Chats:" + str(len(chats)))
            print("home")
            context={'page': 'home', 'chats': chats}
            return render(request, 'home/index.html',context )

def chat(request, url, name):
    if request.method == 'GET':
        messages = get_messages("https://www.facebook.com/messages/t/" +url, name)
        print("chat")
        context={'messages': messages, 'page': 'chat', 'sender_name': name, 'url': url}
        return render(request, 'home/messages.html', context)

@csrf_exempt
def message_list(request, sender=None, url=None):
    print("message list")
    print(request)
    data = JSONParser().parse(request)
    print(data)

    url = data['url']
    message = data['message']

    messages.append({'sender': "You sent", 'message': message})

    send_message("https://www.facebook.com/messages/t/" +url, message)

    return JsonResponse({'message': message}, status=201)

    
