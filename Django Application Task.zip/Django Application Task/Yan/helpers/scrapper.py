# change user-agent to avoid blocking from facebook
# add random time delay to avoid blocking from facebook
# use proxy to avoid blocking from facebook
# clear cookies to avoid blocking from facebook

# pip install webdriver-manager --upgrade
# pip install selenium


#imports here
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.proxy import Proxy, ProxyType
from webdriver_manager.chrome import ChromeDriverManager
import time
import random
import pandas as pd
import requests
from extension import proxies

# from seleniumwire import webdriver
# from selenium.webdriver.chrome.service import Service as ChromeService
# from webdriver_manager.chrome import ChromeDriverManager
# from selenium.webdriver.common.by import By
# import time

username = 'huciskrm'
password = '7qwrii5oq0el'
endpoint = '154.13.134.56'
port = '5082'

# proxy_username = "huciskrm"
# proxy_password = "7qwrii5oq0el"
# seleniumwire_options = {
#     "proxy": {
#         "http": f"http://{proxy_username}:{proxy_password}@154.13.134.56:5082",
#         "verify_ssl": False,
#     },
# }
# driver = webdriver.Chrome(seleniumwire_options=seleniumwire_options)


# Set up proxy options for Chrome
chrome_options = webdriver.ChromeOptions()

proxies_extension = proxies(username, password, endpoint, port)
# chrome_options.add_extension(proxies_extension)

# Add other options as needed
prefs = {"profile.default_content_setting_values.notifications": 2}
chrome_options.add_experimental_option("prefs", prefs)

# Initialize Chrome browser with ChromeDriver managed by the service and additional options
driver = webdriver.Chrome("C:/Users/HP/chromedriver.exe", options=chrome_options)

#open the webpage
# driver.get("https://www.google.com/search?q=hospital+near+me&oq=hospital+near+me")
# driver.get("http://whatismyipaddress.com/")
driver.get("https://www.facebook.com/")

#target username
username = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "input[name='email']")))
password = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "input[name='pass']")))

my_email = "garmnets.square@gmail.com"
my_password = "Acc123@123"

# enter username or password
username.clear()
username.send_keys(my_email)
password.clear()
password.send_keys(my_password)

#target the login button and click it
button = WebDriverWait(driver,2).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "button[type='submit']"))).click()

time.sleep(random.randint(5, 10)) # wait for 5 seconds to load the page
print(driver.current_url)
while driver.current_url != "https://www.facebook.com/?sk=welcome":
    print("Logging in")
    time.sleep(5)

print("Logged in") # you should be logged in by now

# Move to the Messages page
driver.get("https://www.facebook.com/messages/t")

time.sleep(random.randint(5, 10)) # wait for 5 seconds to load the page

# click on the Marketplace for displaying all the messages
div_element = WebDriverWait(driver, 10).until(
    EC.element_to_be_clickable((By.CSS_SELECTOR, "div.x1i10hfl.x1qjc9v5.xjbqb8w.xjqpnuy.xa49m3k.xqeqjp1.x2hbi6w.x13fuv20.xu3j5b3.x1q0q8m5.x26u7qi.x972fbf.xcfux6l.x1qhh985.xm0m39n.x9f619.x1ypdohk.xdl72j9.x2lah0s.xe8uvvx.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.x2lwn1j.xeuugli.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1n2onr6.x16tdsg8.x1hl2dhg.xggy1nq.x1ja2u2z.x1t137rt.x1q0g3np.x87ps6o.x1lku1pv.x1a2a7pz.x1lq5wgf.xgqcy7u.x30kzoy.x9jhf4c.x1lliihq"))
)
div_element.click() # click on the Marketplace

# scroll down to load all the messages
time.sleep(random.randint(5, 10))

# get the Marketplace scrollable element
scroll_messages = driver.find_element(By.XPATH, '//div[@aria-label="Marketplace"]/div/div/div')

# SCrolling code
# Get scroll height
last_height = driver.execute_script("return arguments[0].scrollHeight", scroll_messages)

while True:
    # Scroll down to bottom
    driver.execute_script("arguments[0].scroll(0, arguments[0].scrollHeight);", scroll_messages)

    # Wait to load page
    time.sleep(random.randint(20, 30))

    # Calculate new scroll height and compare with last scroll height
    new_height = driver.execute_script("return arguments[0].scrollHeight", scroll_messages)
    if new_height == last_height:
        break
    last_height = new_height

# get the all inbox messages links
links = scroll_messages.find_elements(By.TAG_NAME, 'a')
anchors = [a.get_attribute('href') for a in links]
anchors_text = [a.text.split('\n')[0] for a in links]

# create a list of dictionary
anchors = [{'name': anchors_text[i], 'url': anchors[i]} for i in range(len(links))]

# print the links
for name, url  in enumerate(anchors):
    print("Name {}: Url {}".format(name, url))

chats = []
# get the messages from the links
for url in anchors:
    # Open the message link page
    driver.get(url['url'])

    # wait for random seconds to load the page
    time.sleep(random.randint(5, 10))
    # scroll down to load all the messages
    # driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

    # <div aria-label="Messages in conversation titled Shahzaib · Red T-Shirt" class="x1uipg7g xu3j5b3 xol2nv xlauuyb x26u7qi x19p7ews x78zum5 xdt5ytf x1iyjqo2 x6ikm8r x10wlt62" role="grid">flex
    # Find the whole message box
    # messageBox = driver.find_element(By.XPATH, "/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div[2]/div/div/div/div/div/div/div/div/div/div[2]/div/div/div[1]/div/div/div/div[1]/div/div/div[3]/div")
    # messageBox = driver.find_element(By.XPATH, '//div[@data-pagelet="MWInboxDetail_MessageList"]')
    b = '//div[@aria-label="Messages in conversation titled ' + url['name'] +'"'
    messageBox = driver.find_element(By.XPATH, '//div[@aria-label="Messages in conversation titled ' + url['name'] + '"]')

    # Find all div messages divs
    messageBars = messageBox.find_elements(By.CLASS_NAME , '__fb-light-mode.x1n2onr6')
    if messageBars == []:
        messageBars = messageBox.find_elements(By.CLASS_NAME , '__fb-dark-mode.x1n2onr6')

    # get the total messages
    totalMsgs = len(messageBars)
    print(url)
    print("Before Filtering: "+ str(totalMsgs))

    # filtering the messages removing unwanted texts
    # remove the only first message with following text
    text_to_remove =  ['Buyer details', 'Message sent\nEnter', 'Beware of common scams using payment apps\nWatch out for fake emails or requests to upgrade your payment account.', 'Learn more',"You created this group",
            "You're not connected to 1 member",
            "You changed the group photo.",] 
    for text in text_to_remove:
        messageBars = [x for x in messageBars if text not in x.text]
    print("After Filtering: "+str(len(messageBars)))

    # remove the last message with following text
    messages = []
    #for index, messageBar in enumerate(messageBars):
    for idx in range(0, len(messageBars), 2):
        # append the text first line as sender and second line as a message create a list of dictionary
        if idx + 1 >= len(messageBars):
                break
        mTexts = messageBars[idx].text.split('\n')
        messages.append({'sender': mTexts[0], 'message': messageBars[idx+1].text})

    # take the input from the user does he wants to reply or not
    # if yes then reply to the message
    # if no then continue
    reply = 'n'#input("Do you want to reply to the messages? (y/n): ")
    
    if reply == 'y':
        # Find the message input element
        message_input = driver.find_element(By.XPATH, '//div[@aria-label="Message"]/p')
        #message_input = driver.find_element(By.XPATH, "//p[@class='xat24cr xdj266r xdpxx8g']//span")

        # Get user input for the message
        user_message = input("Enter your message: ")

        # Clear any existing text in the message input field
        message_input.clear()

        # Type the user's message into the input field
        message_input.send_keys(user_message)
        message_input.send_keys(Keys.RETURN)
        # Find the send button and click it
        # send_button = driver.find_element(By.XPATH, "//div[@aria-label='Press Enter to send']")
        # send_button.click()

        # wait
        time.sleep(random.randint(5, 10))

        messages.append({'sender': 'You sent', 'message': user_message})
        print("Message sent")

    # append the messages to the chats list
    chats.append(messages)

# print the messages
for account in chats:
    print(account)
print("end")
driver.quit()
